# FXJSINKS Forex Website

Welcome to the FXJSINKS Forex teaching website! This project is built with **React** and **Tailwind CSS** to provide a modern, responsive platform where pupils can explore courses, check pricing, and enroll via email.

## Features

- Courses grouped by **levels**: Beginner / Intermediate / Advanced  
- **Weekly/Monthly pricing toggle** (K50/week, K300/month)  
- **Level badges** (Green / Yellow / Red) for easy identification  
- **Enroll buttons** pre-filled with your email (`jsinks925@gmail.com`)  
- **Responsive layout** for mobile and desktop  
- **Blue + White theme** with placeholder images  

## Project Structure

```
FXJSINKS-Website/
│
├─ package.json              # Project dependencies
├─ tailwind.config.js        # Tailwind setup
├─ postcss.config.js         # PostCSS setup
├─ vite.config.js            # Vite configuration
├─ index.html                # Main HTML file
└─ src/
   ├─ main.jsx               # React entry point
   └─ FXJSinksSite.jsx       # Main website component
```

## Installation & Running Locally

1. Make sure you have **Node.js** installed.
2. Clone the repository:

```bash
git clone https://github.com/YOUR_USERNAME/fxjsinks-website.git
cd fxjsinks-website
```

3. Install dependencies:

```bash
npm install
```

4. Start the development server:

```bash
npm run dev
```

5. Open your browser at `http://localhost:5173` to view the website.

## Deployment

You can deploy the website using **Vercel** (recommended for React + Tailwind projects):

1. Go to [https://vercel.com](https://vercel.com) and log in.  
2. Click **New Project → Import Git Repository**.  
3. Select your GitHub repository (`fxjsinks-website`).  
4. Click **Deploy**.  

Your FXJSINKS website will be live in minutes!

## Customization

- Replace placeholder images in `src/FXJSinksSite.jsx`  
- Update course descriptions, levels, or pricing  
- Add WhatsApp or other contact info in the contact section  
- Adjust theme colors in Tailwind configuration  

## Contact

For any questions or support, email: **jsinks925@gmail.com**

---

**FXJSINKS – Practical Forex Lessons & Mentorship**
