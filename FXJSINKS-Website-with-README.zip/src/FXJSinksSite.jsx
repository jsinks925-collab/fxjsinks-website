import React, { useState } from 'react';

export default function FXJSinksSite() {
  const [priceMode, setPriceMode] = useState('week');
  const lessons = [
    { id: 1, level: 'Beginner', title: 'Beginner Forex Course', priceWeek: 'K50', priceMonth: 'K300', blurb: 'Learn basics.', img: 'https://via.placeholder.com/200' },
    { id: 2, level: 'Beginner', title: 'Chart Patterns', priceWeek: 'K50', priceMonth: 'K300', blurb: 'Chart patterns.', img: 'https://via.placeholder.com/200' },
    { id: 3, level: 'Intermediate', title: 'Candlestick Mastery', priceWeek: 'K50', priceMonth: 'K300', blurb: 'Candlestick mastery.', img: 'https://via.placeholder.com/200' },
    { id: 4, level: 'Intermediate', title: 'Smart Money Concept', priceWeek: 'K50', priceMonth: 'K300', blurb: 'Smart Money.', img: 'https://via.placeholder.com/200' },
    { id: 5, level: 'Advanced', title: 'Mentorship', priceWeek: 'K50', priceMonth: 'K300', blurb: 'Mentorship.', img: 'https://via.placeholder.com/200' },
    { id: 6, level: 'Advanced', title: 'Swing Trading Strategy Course', priceWeek: 'K50', priceMonth: 'K300', blurb: 'Swing trading.', img: 'https://via.placeholder.com/200' },
  ];
  return (<div className='min-h-screen bg-blue-50 text-slate-800 p-6'>
    <h1 className='text-2xl font-bold mb-4'>FXJSINKS Forex Website</h1>
    <div className='grid sm:grid-cols-2 lg:grid-cols-3 gap-4'>
      {lessons.map(l => (<div key={l.id} className='bg-white p-4 rounded shadow'>
        <img src={l.img} alt={l.title} className='w-full h-32 object-cover rounded'/>
        <h2 className='font-semibold mt-2'>{l.title}</h2>
        <span className='px-2 py-1 rounded bg-green-200'>{l.level}</span>
        <p className='mt-1'>{l.blurb}</p>
        <p className='mt-2 font-bold'>{priceMode==='week'?l.priceWeek+'/week':l.priceMonth+'/month'}</p>
      </div>))}
    </div>
  </div>);
}